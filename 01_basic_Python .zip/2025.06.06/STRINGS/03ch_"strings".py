# STRINGS

name = "arun yadav"
print(name[0:3])  # slicing a string (3 is not included)
print(name[:3])  # khali Mtlab 0
print(name[0:])  # khali matlab length
character1 = name[1]
print(character1)
print(name[-4:-1])
print(name[1:4])

a = "0123456789012345678901234567890"
print(a[1:6:2])  # ye 5 tak jayega 2-2 ka jump karte hue 
print(a[2:14:3])   # ye 13 tak jayega 3-3 ka jump karte hue

alphabets = "abcdefghijklmnopqrstuvwxyz"
print(len(alphabets))
print(alphabets[0:26:1])
print(len(alphabets[0:26:1]))
print(alphabets[0:26:2])
print(len(alphabets[0:26:2]))

#STRING FUNCTIONS 
# 1 len I know this
alphabets = "abcdefghijklmnopqrstuvwxyz"
print(len(alphabets))
print(alphabets.endswith("xyz"))  # True
print(alphabets.capitalize())  # it capitalize only first letter 
print(alphabets.index("xyz"))  # ye pahle letter ka index batata hai
print(alphabets.count("a"))   # koi word kitni baar aya hai usko count karta hai
print(alphabets.find("r"))  # this returns occurence of first index of that word
x = alphabets.replace("xyz","aaaaaaa is a good good boy boy ")
print(x)
print(x.upper())  # ye har ek letter ko capital kar dega
print(x.lower())   # ye har ek letter ko small kar dega 

#ESCAPE SEQUENCE CHRACTERS
char = "Hi my name is arun yadav \n I am learning python from \"codewithharry\" \n because \' I want to learn fast and learn a lot in less time.\nmy goal is to finish his 11 hr lecture in 2.5 days  "
print(char)





