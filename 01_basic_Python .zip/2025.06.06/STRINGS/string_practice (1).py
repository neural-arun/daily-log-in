# WAP display a user entered name followed by good afternoon
name = input("Enter your name :")
print(f"Good afternoon, {name}")




