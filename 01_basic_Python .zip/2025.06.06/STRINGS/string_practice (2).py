#02 WAP to fill in a letter template given below with name and date
letter = '''
Dear <|name|>,
you are selected!
<|Date|>'''
print(letter.replace("<|name|>","Arun").replace("<|Date|>","1 november 2025"))





