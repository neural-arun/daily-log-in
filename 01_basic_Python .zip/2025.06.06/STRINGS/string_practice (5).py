#  STRINGS ARE IMMUTABLE WHICH MEANS THAT YOU CANNOT CHANGE THEM BY RUNNING FUNCTIONS ON THEM WHEN WE RUN A FUNCTION ON A STRINGS NEW STRING GET CREATED ORIGINAL STRING REMAINS SAME 

# WAP to format the following letter using escape sequence characters
#letter = "Dear Harry this python course is nice! thanks"

letter = "Dear Harry,\n \tthis python course is nice!\nthanks"
print(letter)
