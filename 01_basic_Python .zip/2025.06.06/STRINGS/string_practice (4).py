# WAP to detect double space in a string 
name  ="arun  yadav is a  good  boy  "
print(name.find("  "))
# WAP to replace the double space from problem 3 with single spaces.
print(name.replace("  "," "))

 
print(name)  # yha par original string hi print hogi kyonki string immutable hoti hai
 
 
 
 

