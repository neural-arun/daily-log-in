# WAP to detect double space in a string 
name  ="arun  yadav is a  good  boy  "
print(name.find("  "))
