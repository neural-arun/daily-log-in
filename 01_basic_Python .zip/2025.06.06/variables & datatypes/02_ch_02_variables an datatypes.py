#WAP to add two numbers
a = 2
b =  6
print(a +b)

#find remainder when a number is divided by z
c = 47
d = 6
print(c%d)
# check type of variable assigned using input function

print(type(a))

e = 34
f = 80
print(e>f)

# WAP find avg of two numbers entered by the user
g =float(input("Enter your number 1 :"))

h =float(input("Enter your number 2 :"))
print(int((g+h)/2))

# WAP calculate the square of a number entered by the user 
I = float(input("Enter the number you want square of :"))
print(int(I**2))