#chapter 1 modules comments and pip 
# using python as a calculator  # this is a single line comments 
""" this is a multi line comments as I can type here multiplr lines which will not be executed in the terminal  """
#QUESTION 4 
# WAP to print the contents of a diary using the os module ?

import os
from datetime import datetime

# Step 1: Create a folder called "Diary"
diary_folder = "Diary"
os.makedirs(diary_folder, exist_ok=True)  # Create if not already present

# Step 2: Generate a filename with today's date
today = datetime.now().strftime("%Y-%m-%d")  # e.g., '2025-06-05'
file_path = os.path.join(diary_folder, f"{today}.txt")

# Step 3: Get user input for diary content
print("Enter your diary content below. Type 'END' in a new line to finish.")
lines = []
while True:
    line = input()
    if line.strip().upper() == 'END':
        break
    lines.append(line)

# Step 4: Write the diary content to the file
with open(file_path, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print(f"Diary entry saved successfully to {file_path}")


