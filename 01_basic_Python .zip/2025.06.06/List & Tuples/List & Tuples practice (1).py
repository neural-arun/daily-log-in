# WAp to store 7 fruits in a list entered by user

fruits = [input("Enter fruit 1"),input("Enter fruit 2"),input("Enter fruit 3"),input("Enter fruit 4"),input("Enter fruit 5"),input("Enter fruit 6"),input("Enter fruit 7")]
print(fruits)
