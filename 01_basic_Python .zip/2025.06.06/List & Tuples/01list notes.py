friends = ["apple","orange",5,345.06,False,"Aakash","rohan"]

print(friends[0])
friends[0] = "grapes"
print(friends[0])  # unlike strings lists are mutable 

#a list can be indexed, sliced just like strings 
print(friends[5])
print(friends[1:5]) # ye list mein se 1-5 tak ki saari values de dega

# list methods -- ye methods list kohi change karte hain 

friends.append("ashutosh") #append ka Mtlab hota hai jod dena at the end
print(friends)
friends.insert(6,"ram")
print(friends)

l1 = [13,67,35,646,75,463]
l1.sort()
print(l1)
l1.insert(4,556)   # ye changed list mein hi insert karega na ki original list mein kyonki list mutable hoti hai 
print(l1)
x = l1.pop(4) # ye index 4 ki value ko return karega 
print(x)
print(l1)   # ab is list mein index 4 ki value nhi hogi
l1.remove(35)  # will remove 31 from list 
print(l1)