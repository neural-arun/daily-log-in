# WAP to check that a tuple canot be changed in python
a = ("arun","sarita","chitra",34,56,78)
a[2] = "uday"   # ab yha par error ayega ki tuple does not support item assignment
print(a)


