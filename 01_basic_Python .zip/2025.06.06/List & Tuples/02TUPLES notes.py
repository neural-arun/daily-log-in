#  TUPLe is an immutable data type in python 

b = () # empty tuple
d = (1)  # ye class  integer mein aa jayega 
c = (1,) # tuple with a single element
a = (1,2,34,56,77,78,5,353,35,33353)
print(type(a))  # class tuple 
# tuple does not support item assignments 
# TUPLE METHODS
v = (1,2,2,2,2,2,34,56,77,78,5,353,35,33353)
no = v.count(2) # tuple mein koi kitni baar aaya hai ye batata hai
print(no)
print(v.index(2))  # will return the index of first occurence of 1 in v
