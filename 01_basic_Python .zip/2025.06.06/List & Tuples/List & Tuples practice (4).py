#WAP to sum a list with 4 numbers 
numbers = [2,3,4,56,1]
 # sum Is a built in function which gives us sum of numbers in a datatype
print(sum(numbers)) 



