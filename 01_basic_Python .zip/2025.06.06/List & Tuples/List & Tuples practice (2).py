# WAP to accept marks of 6 students and display them in a sorted manner
marks = []
S1 = input("Enter marks of student 1 ")
marks.append(S1)
S2 = input("Enter marks of student 2 ")
marks.append(S2)
S3 = input("Enter marks of student 3 ")
marks.append(S3)
S4 = input("Enter marks of student 4 ")
marks.append(S4)
S5 = input("Enter marks of student 5 ")
marks.append(S5)
S6 = input("Enter marks of student 6 ")
marks.append(S6)
print(marks.sort())  # this returns none value 
marks.sort()
print(marks)  # ab bhi sahi nahi ayega kyonki input function sirf string leta hai aayega 

marks1 = []
S1 = int(input("Enter marks of student 1 "))
marks1.append(S1)
S2 = int(input("Enter marks of student 2 "))
marks1.append(S2)
S3 = int(input("Enter marks of student 3 "))
marks1.append(S3)
S4 = int(input("Enter marks of student 4 "))
marks1.append(S4)
S5 = int(input("Enter marks of student 5 "))
marks1.append(S5)
S6 = int(input("Enter marks of student 6 "))
marks1.append(S6)
print(marks.sort())  # this returns none value 
marks1.sort()
print(marks1)  # ab sahih ayega