# WAP to count the numbers of zeros on the following tuple
# A = (7,0,8,0,0,9)
A = (7,0,8,0,0,9)
x = A.count(0)
print(x)
